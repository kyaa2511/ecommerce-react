import React, { Component } from 'react';

class Login extends Component {

        constructor(props) {
            
            super(props); 
            
            this.state = { email:'', password:'', message: '' };
        }
   
    render() {

        return (
        
            <div className='col-lg-9'>
                <h4 className="m-1 p-2 border-bottom">Login</h4>
            <form action="">
                {/* Email starts */}
                {/* className="form-group form-row" */}
                <div className='mb-3'> 
                    
                    <label htmlFor="login" className="col-lg-4 form-label">Email:</label>
                    <input 
                        type="text" 
                        autoComplete='username' 
                        className="form-control" 
                        value= {this.state.email}
                        onChange={(event) => {this.setState({email: event.target.value});}} />
                </div>
                {/* Email ends */}

                {/* Password starts */}
                <div className="form-group form-row">
                    <label htmlFor="" className="col-lg-4">Password:</label>
                    <input type="password"
                    autoComplete='current-password' 
                    className="form-control" 
                    value= {this.state.password}
                    onChange={(event) => {this.setState({password: event.target.value});}}
                     />
                </div>
                {/* Password ends */}
                </form>
                <div className='float-end'>
                    
                    {this.state.message}  
                    <button 
                    className="btn btn-primary m-2" 
                    onClick={this.onLoginClick}>Login
                    </button>
                    
                </div>
    
            </div>
        )
        
    } //end of render

    onLoginClick = async() => {

        var response = await fetch(`http://localhost:5000/users?email=${this.state.email}&password=${this.state.password}`, 
        {method: 'GET'});

        var body = await response.json();
        
        console.log(body);
        if(body.length > 0) {

            // update the message property of state of current component
            this.setState({
                // success
                message: (<span className="text-success">Successfully Logged-In</span>)
            
            });
            // call the App Component's updateIsLoggedInStatus method
            // this.props.updateIsLoggedInStatus(true);
            this.props.updateIsLoggedInStatus(true);
        
        } else {
            // error
            this.setState({
            
                message: (<span className="text-danger">Logged-In Failed</span>)
            
            });
        }
    }
}

export default Login;