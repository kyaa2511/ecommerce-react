import React, { Component } from 'react';

import {NavLink} from 'react-router-dom';


class NavBar extends Component {
   
  constructor(props) {

    super(props);
    this.state={isLoggedIn: false};
  }
    render() {
        return (
<React.Fragment>
  <div>
    <nav className="navbar navbar-expand-lg navbar-dark bg-success">
      <div className="container-fluid">
        <a className="navbar-brand" href="#">eCommerce</a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
          <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div className="navbar-nav">
              
              {!this.props.isLoggedIn? (<NavLink to="/" 
                className="nav-link" 
                actveclassname='active' 
                exact={"true"} 
                aria-current="page">
                  Login
                  </NavLink>
              ) : ('')}

              {this.props.isLoggedIn ? (<NavLink to="/" 
                className="nav-link" 
                actveclassname='active' 
                exact={"true"} 
                aria-current="page">
                  Login
                  </NavLink>
              ) : ('')}

              {this.props.isLoggedIn ? (<NavLink to="/dashboard" className="nav-link" actveclassname='active' aria-current="page" >Dashboard</NavLink>) : ('')}
              {this.props.isLoggedIn ? (<NavLink to="/cart" className="nav-link" actveclassname='active' aria-current="page" >Shopping Cart</NavLink>) : ('')}
              {this.props.isLoggedIn ? (<NavLink to="/customers" className="nav-link" actveclassname='active'  aria-current="page" >Customers</NavLink>) : ('')}

              
              
              
              
            </div>
          </div>
      </div>
    </nav>
  </div>
 </React.Fragment>            
    );
  }
}

export default NavBar;