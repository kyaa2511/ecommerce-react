import React, { Component } from 'react';
import NavBar from './navbar';
import ShoppingCart from './ShoppingCart';
import Login from './Login';
import CustomerList from './CustomersList';
import Dashboard from './Dashboard';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import NoMatchPage from './NoMatchPage';


class App extends Component {
    
    constructor(props){

        super(props)

        this.state = {isLoggedIn: false};
    }

    render() {
        
        return(
            
            <BrowserRouter>
                <NavBar isLoggedIn={this.state.isLoggedIn} />
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-lg-3"></div>
                        div.col
                    </div>
                    <Routes>
                        <Route path='/' 
                               exact 
                               element={(props)=>(
                               <Login 
                                {...props} 
                                updateIsLoggedInStatus = {this.updateIsLoggedInStatus} 
                                />
                               )} 
                             />
                        <Route path='/cart' element={<ShoppingCart />} />
                        <Route path='/customers' element={<CustomerList />} />
                        <Route path='/dashboard' element={<Dashboard />} />
                        <Route path='*' element={<NoMatchPage />} />
                    </Routes>
                </div>
            </BrowserRouter>
        );      
    }

    updateIsLoggedInStatus = (status) => {

        this.setState({ isLoggedIn: status });
    
    };

}

export default App;