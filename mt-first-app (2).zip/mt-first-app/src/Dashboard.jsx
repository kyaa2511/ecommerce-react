import React, { Component } from 'react';

class Dashboard extends Component {

    render() {

        return (
            <div>
                <h4>Dashboard</h4>
            </div>
        )
    }
}

export default Dashboard;