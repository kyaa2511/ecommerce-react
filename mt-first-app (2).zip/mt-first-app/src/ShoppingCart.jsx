import React, { Component } from 'react';
import Product from './Product';

class ShoppingCart extends Component {
    // executes when component is mounted
   constructor(props) {
    
   
    super(props);  //calling super class's construtor

    // inirialization of the state
    this.state = {

        products: [],
   };
}
      
    render() {
console.log('render - ShoppingCart');
    return( 
        <div>
            <h4>Shopping Cart</h4> 

            <div className='row'> 
                
                {this.state.products.map( (prod) => {
                
                // must have a key that is unquiue
                
                return <Product 
                        key={prod.id}  
                        product={prod}  
                        onIncrement={this.handleIncrement}
                        onDecrement={this.handleDecrement}
                        onDelete={this.handleDelete}
                        > 
                   
                            <button className="btn btn-primary" type='button'>Buy Now</button>

                        </Product>
            } )} </div>
        </div>
    )
   } 

//Executes after constructor and render method (includes life cycle of child comnponents, if any) of current commponent
   componentDidMount = async() => {
    
    //fetch data from data source
    var response = await fetch('http://localhost:5000/products', {method: 'GET'});
     
    var prods = await response.json()    
    console.log(prods);

    this.setState({products: prods});
    
    };

   

   componentDidUpdate  = () => {
       
   }

   componentWillUnmount = () => {
       
   }

   componentDidCatch = (error, info) => {
    // console.log('componentWillUnmount - ShoppingCart');
    // console.log(error, info);

    localStorage.lastError = `${error}\n${JSON.stringify(info)}`;
   }

   handleIncrement = (product, maxValue) => {

    // copy the 'products' obj into allProducts variable using the spread operator (...)
    let allProducts = [...this.state.products];
    let index = allProducts.indexOf(product);
    
        if(allProducts[index].quantity < maxValue) {
            
            allProducts[index].quantity ++ ;

        // update the allProduct obj with new quantity when '+' btn is pressed
        this.setState({products: allProducts});

        }
   }

   handleDecrement = (product, minValue) => {

    // copy the 'products' obj into allProducts variable using the spread operator (...)
    let allProducts = [...this.state.products];
    let index = allProducts.indexOf(product);
    
        if(allProducts[index].quantity > minValue) {
            
            allProducts[index].quantity -- ;

            // update the allProduct obj with new quantity when '+' btn is pressed
            this.setState({products: allProducts});

        } 
   }

// executes when the user clicks on Delete(x) btn in the Product component
    handleDelete = (product) => {

        let allProducts = [...this.state.products];
        let index = allProducts.indexOf(product);

        if(window.confirm('Are you sure?'))

        // delete product based on index
        allProducts.splice(index, 1);

        // update the state of current component (parent component)
        this.setState({products: allProducts})
    }

}

export default ShoppingCart;