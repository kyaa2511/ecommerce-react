import React, { Component } from 'react';

class CustomersList extends Component {

    state = {

        pageTitle: 'Customers',
        customerCount: '5',
        customers: [
            {
                id:1,
                name:'Stacey',
                phone:'912-9675',
                address: {
                    city: '',
                },
                photo: 'https://picsum.photos/id/1010/60'
            },
            {
                id:2,
                name:'Jones',
                phone:'654-6548',
                address: {
                    city: 'Los Angeles',
                },
                photo: 'https://picsum.photos/id/1014/60'
            },
            {
                id:3 ,
                name:'Scott',
                phone:'',
                address: {
                    city: 'Houston',
                },
                photo: 'https://picsum.photos/id/1013/60'
            },
            {
                id:4,
                name:'Allen',
                phone:'543-4873',
                address: {
                    city: 'New York City',
                },
                photo: 'https://picsum.photos/id/1011/60'
            },
            {
                id:5,
                name:'',
                phone:'',
                address: {
                    city: 'Seattle',
                },
                photo: 'https://picsum.photos/id/1012/60'
            },
            
        ],

    };

    customerNameStyle = (name) => {

        
    }
    
    render() {
        
        return(
        
            <div>
                <h4 className='m-1 p-1'> 
                    {this.state.pageTitle} 
                    <span className="badge bg-secondary m-2"> {this.state.customerCount}</span>
                    <button className="btn btn-info" onClick= {this.onRefreshClick} >Refresh</button>

                </h4>

                <table className="table">
                    <thead>
                      <tr>
                        <th className='text-center' >#</th>
                        <th className='text-center' >Photo</th>
                        <th className='text-center' >Customer's Name</th>
                        <th className='text-center' >Phone</th>
                        <th className='text-center' >City</th>
                        </tr>  
                    </thead>
           
                    <tbody>
                        { this.getCustomerRow() }
                    </tbody>
                </table>
                
            </div>

        );
    }

    // Executes when the user clicks on Refresh button
    onRefreshClick = () => {
        // Update the state using setState method - so that react updates the brower
        console.log('Refresh clicked');
        this.setState({
            customerCount: 7
        })
    }

    getPhoneToRender =(info) => {

        return info === '' || info === NaN ?  
        (<div className='p-3 mb-2 bg-warning text-dark text-center '>No Input</div>) 
        : (<div className='p-3 mb-2 bg-success text-light text-center'> {info} </div>)
    }

    getCustomerRow = () => {

        return (this.state.customers.map((customer, index) => {

            return (

                <tr key={customer.id} >
                    
                    <td> 
                       <div className='p-2  mt-2 bg-secondary text-center text-white '> {customer.id} </div>
                    </td>
                    
                    <td> 
                        <img src= {customer.photo} alt="customer" />
                        <div>
                            <button className='btn btn-sm btn-secondary' onClick={ () => {this.onChangePictureClick(customer, index);}} >
                                Change Picture
                            </button>
                        </div>
                    </td>
                    
                    <td style={ this.customerNameStyle(customer.name) }> 
                        {this.getPhoneToRender(customer.name)}
                    </td>
                    
                    <td> 
                        {this.getPhoneToRender(customer.phone)} 
                    </td>
                    
                    <td> 
                        {this.getPhoneToRender(customer.address.city)} 
                    </td>
                </tr>
            );
        }))
    }


    onChangePictureClick = (customer, index) => {

        // console.log(customer);
        // console.log(index);

        // changes or updates the page 
        var custArr = this.state.customers;

        custArr[index].photo = 'https://picsum.photos/id/110/60';

        // updating customers object with photo
        this.setState({customers: custArr});


    }
}

export default CustomersList;

